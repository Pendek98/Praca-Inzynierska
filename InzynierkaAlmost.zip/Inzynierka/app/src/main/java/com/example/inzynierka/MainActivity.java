package com.example.inzynierka;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.inzynierka.adapters.FragmentAdapter;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance("https://praca-inzynierska-2edb2-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference databaseReference = database.getReference();
    FirebaseDatabase database2 = FirebaseDatabase.getInstance("https://praca-inzynierska-2edb2-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference databaseReference2 = database2.getReference().child("ShoppingList");
    ArrayList<RecipesItem> przepisy = new ArrayList<>();
    ViewPager2 viewPager2;
    TabLayout tabLayout;
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentAdapter adapter;
    ArrayList<IngredientItem> ingredientspop = new ArrayList<>();

    ArrayList<String> ingredien = new ArrayList<>();
    ArrayList<IngredientItem> ingredien2 = new ArrayList<>();

    RecipesItem tmpRecipesItem;


    private FirebaseAuth firebaseAuth;

    public ArrayList<IngredientItem> items = new ArrayList<>();

    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //binding = ActivityMainBinding.inflate(getLayoutInflater());
        //setContentView(binding.getRoot());
        setContentView(R.layout.activity_main);
        getdata();

        firebaseAuth = FirebaseAuth.getInstance();


        viewPager2 = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);
/*
        ArrayList<String> tags = new ArrayList<>();
        ArrayList<String> ingr = new ArrayList<>();
        tags.add("Ostre");
        tags.add("Słone");
        ingr.add("Kurczak");
        ingr.add("Ryz");

        RecipesItem recipesItem = new RecipesItem("Nowy","Opis",tags,ingr);
        writeNewRecipe(recipesItem);
*/
      /*  GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken(getString(R.string.default_web_client_id)).requestEmail().build();
        googleSignInClient = GoogleSignIn.getClient(this,googleSignInOptions);

        firebaseAuth = FirebaseAuth.getInstance();

        binding.googleSignInBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onCLick(View v){
                Log.d(TAG,"onCLick: begin "Google SignIn);
                Intent intent = googleSignInClient.getSignInIntent();
                startActivityForResult(intent,RC_SIGN_IN);
            }
        })*/

        adapter = new FragmentAdapter(fragmentManager, getLifecycle());
        viewPager2.setAdapter(adapter);
        tabLayout.addTab(tabLayout.newTab().setText("Przepisy"));
        tabLayout.addTab(tabLayout.newTab().setText("Lista Zakupów"));
        tabLayout.addTab(tabLayout.newTab().setText("Dom"));
        tabLayout.addTab(tabLayout.newTab().setText("?????"));


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                tabLayout.selectTab(tabLayout.getTabAt(position));
            }
        });


    }


    public void CreateRecipe(int numb) {

        viewPager2.setCurrentItem(numb);

    }

    public void writeNewRecipe(RecipesItem recipesItem) {
        DatabaseReference recipes = databaseReference.child("Recipes").push();
        recipes.setValue(recipesItem);
        recipes.push();
    }

    public void updateNewRecipe(String name, String desc, ArrayList<String> tags) {
        DatabaseReference recipes = databaseReference.child("Recipes");
        RecipesItem recipesItem = new RecipesItem(name, desc, tags, ingredien);

        recipes.setValue(recipesItem);
        recipes.push();
    }

    public void openRecipe(RecipesItem recipe){
        tmpRecipesItem = recipe;
        viewPager2.setCurrentItem(5);
    }


    public void writeNewShoppingItem(IngredientItem ingredientItem) {
        DatabaseReference ingredients = databaseReference.child("ShoppingList").push();
        ingredients.setValue(ingredientItem);
        ingredients.push();
    }

    public void writeNewHomeItem(IngredientItem ingredientItem) {
        DatabaseReference ingredients = databaseReference.child("HomeList").push();
        ingredients.setValue(ingredientItem);
        ingredients.push();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.ingredientmenu, menu);
        return true;
    }

    public void createNewContactDialog() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        ImageView imageView = contactPopupView.findViewById(R.id.newListIcon);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                createSecoundDialog();
            }
        });
    }

    public void createSecoundDialog() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup2, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();
        EditText ingredientName, ingredientAmount;
        Button savebtn;
        ingredientName = (EditText) contactPopupView.findViewById(R.id.newIngredientName);
        ingredientAmount = (EditText) contactPopupView.findViewById(R.id.newIngredientAmount);
        savebtn = (Button) contactPopupView.findViewById(R.id.saveIngredient);

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeNewShoppingItem(new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString()));
                ingredientspop.add(new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString()));
                Log.v("OnClick", "" + ingredientName.getText().toString());
                dialog.dismiss();
            }
        });


    }

    public void createNewContactDialog2() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        ImageView imageView = contactPopupView.findViewById(R.id.newListIcon);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                createSecoundDialog2();
            }
        });
    }

    public void createSecoundDialog2() {

        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup2, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();
        EditText ingredientName, ingredientAmount;
        Button savebtn;
        ingredientName = (EditText) contactPopupView.findViewById(R.id.newIngredientName);
        ingredientAmount = (EditText) contactPopupView.findViewById(R.id.newIngredientAmount);
        savebtn = (Button) contactPopupView.findViewById(R.id.saveIngredient);

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ingredien.add(0, ingredientName.getText().toString());
                ingredien2.add(0, new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString()));
                dialog.dismiss();
            }
        });
    }


    public ArrayList<IngredientItem> getIngredients() {
        return items;
    }


    public void deletedata(IngredientItem ing) {
        databaseReference2.child(ing.ingredientID).removeValue();
    }


    private void getdata() {

        // calling add value event listener method
        // for getting the values from database.
        databaseReference2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                items.removeAll(items);


                HashMap<String, IngredientItem> hashMap = (HashMap<String, IngredientItem>) snapshot.getValue();

                Log.v("Tags", "" + hashMap.keySet());
                Set<String> keySet = hashMap.keySet();
                keySet.forEach((n) -> {
                    DataSnapshot newsnapshot = snapshot.child(n);
                    IngredientItem recipesItem = newsnapshot.getValue(IngredientItem.class);
                    items.add(0, new IngredientItem(recipesItem.getIngredientName(), recipesItem.getAmount()));
                    items.get(0).setIngredientID(n);
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}

