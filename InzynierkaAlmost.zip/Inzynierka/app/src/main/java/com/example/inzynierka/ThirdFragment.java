package com.example.inzynierka;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.inzynierka.adapters.HomeAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;


public class ThirdFragment extends Fragment implements SelectListener{


    public ArrayList<IngredientItem> items = new ArrayList<>();
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://praca-inzynierska-2edb2-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference databaseReference = database.getReference().child("HomeList");



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        items.add(new IngredientItem("Ziemniaki","15"));
        items.add(new IngredientItem("Schabowe","69"));
        items.add(new IngredientItem("Filety","4"));
        items.add(new IngredientItem("Ryż","1"));
        items.add(new IngredientItem("Mleko","120"));
        items.add(new IngredientItem("Tyskie","999"));


        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_third, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.HomeIngredientsList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setAdapter(new HomeAdapter(items,this));
        return view;
    }


    private void getdata() {

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                items.removeAll(items);


                HashMap<String, IngredientItem> hashMap = (HashMap<String, IngredientItem>) snapshot.getValue();

                Log.v("Tags",""+hashMap.keySet());
                Set<String> keySet = hashMap.keySet();

                keySet.forEach((n)->{
                    DataSnapshot newsnapshot = snapshot.child(n);
                    IngredientItem ingredientItem = newsnapshot.getValue(IngredientItem.class);
                    items.add(ingredientItem);
                    Log.v("Tags",""+ingredientItem.getIngredientName());
                });


                /*ArrayList<RecipesItem> recipesItems = hashMap.keySet().stream().collect(
                        Collectors.toCollection(ArrayList::new));

                Spliterator<RecipesItem> recipes = recipesItems.spliterator();
                recipes.forEachRemaining((n) ->filtr(n));
                Log.v("Tags",""+recipesItems.get(0));*/

                //RecipesItem recipesItem = hashMap.getOrDefault(entry.getKey());
                //Log.v("Taggs", " "+recipesItem.toString());
/*
                for(DataSnapshot userSnapshot : snapshot.getChildren())
                for (Map.Entry<String,RecipesItem> entry: map.entrySet()) {
                    RecipesItem recipesItem = hashMap.getOrDefault(entry.getKey());
                    Log.v("Taggs", " " + recipesItem.toString());
                }*/
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // calling on cancelled method when we receive
                // any error or we are not able to get the data.
                //Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onItemClicked(int position) {

    }

    /*public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView recyclerView = view.findViewById(R.id.HomeIngredientsList);;
        view.findViewById(R.id.DeleteIngredient).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = recyclerView.findViewHolderForAdapterPosition();
                items.remove(items.indexOf(this));
            }
        });

    }*/

}