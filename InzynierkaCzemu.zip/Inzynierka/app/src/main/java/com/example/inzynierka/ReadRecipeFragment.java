package com.example.inzynierka;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.inzynierka.adapters.HomeAdapter;
import com.example.inzynierka.adapters.ReadAdapter;


public class ReadRecipeFragment extends Fragment {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_read_recipe, container, false);
        TextView name = view.findViewById(R.id.ReadName);
        TextView desc = view.findViewById(R.id.ReadDescription);
        name.setText(((MainActivity)getActivity()).tmpRecipesItem.getRecipesName());
        desc.setText(((MainActivity)getActivity()).tmpRecipesItem.getDescription());
        RecyclerView recyclerView = view.findViewById(R.id.ReadIngredients);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setAdapter(new ReadAdapter(((MainActivity)getActivity()).tmpRecipesItem.getIngredients()));

        return view;
    }
}