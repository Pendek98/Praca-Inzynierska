package com.example.inzynierka;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.inzynierka.adapters.RecipesListAdapter;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import java.util.Spliterator;


public class FirstFragment extends Fragment implements SelectListener{

    public ArrayList<RecipesItem> items = new ArrayList<>();
    public ArrayList<RecipesItem> filtered = new ArrayList<>();
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://praca-inzynierska-2edb2-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference databaseReference = database.getReference().child("Recipes");
    RecyclerView recyclerView;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onStart() {
        super.onStart();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {




        View view = inflater.inflate(R.layout.fragment_first, container, false);

        Spinner spinner = (Spinner) view.findViewById(R.id.RecipesTags);
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(view.getContext(),R
                .array.spinnerList, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        EditText name = (EditText) view.findViewById(R.id.RecipesNames);
        recyclerView = view.findViewById(R.id.RecipesList);
        RecipesListAdapter adapter = new RecipesListAdapter(items,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setHasFixedSize(true);
        getdata();
        adapter.notifyDataSetChanged();


        return view;
    }

    public void selected(){
        recyclerView.setAdapter(new RecipesListAdapter(filtered,this));
    }
    public void difselect(){
        recyclerView.setAdapter(new RecipesListAdapter(items,this));
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        EditText edit = view.findViewById(R.id.RecipesNames);
        RecyclerView recyclerView = view.findViewById(R.id.RecipesList);
        RecipesListAdapter adapter = new RecipesListAdapter(items,this);
        recyclerView.setAdapter(adapter);

        view.findViewById(R.id.AddRecipes).setOnClickListener(v -> {
            ArrayList<String> tags = new ArrayList<>();
            ArrayList<String> ingredients= new ArrayList<>();
            tags.add("słone");
            tags.add("ostre");
            ingredients.add("Kurczak");
            ingredients.add("Ziemniaki");
            ingredients.add("Przyprawy");
            RecipeCreateFragment recipeCreateFragment = new RecipeCreateFragment();
            ((MainActivity)getActivity()).CreateRecipe(4);
        });

        view.findViewById(R.id.FindRecipes).setOnClickListener(v -> {
            Spliterator<RecipesItem> recipes = items.spliterator();
            Toast.makeText(getContext(),edit.getText(),Toast.LENGTH_LONG).show();
            filtered.removeAll(filtered);
            recipes.forEachRemaining((n) ->filtr(n,edit.getText().toString()));
            recyclerView.setAdapter(new RecipesListAdapter(filtered,this));
            if (filtered.isEmpty())recyclerView.setAdapter(new RecipesListAdapter(items,this));
        });

        Spinner spinner = (Spinner) view.findViewById(R.id.RecipesTags);

        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(view.getContext(),R
                .array.spinnerList, android.R.layout.simple_spinner_item);


        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Spliterator<RecipesItem> recipes = items.spliterator();
                filtered.removeAll(filtered);

                switch (position){
                    case 1:
                        recipes.forEachRemaining((n) ->filtr(n,"Ostre"));
                        selected();
                        break;
                    case 2:
                        recipes.forEachRemaining((n) ->filtr(n,"Łagodne"));
                        selected();
                        break;
                    case 3:
                        recipes.forEachRemaining((n) ->filtr(n,"Słone"));
                        selected();
                        break;

                    default:
                        difselect();
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }


    private void filtr(RecipesItem n,String tag) {
        if (n.tags.contains(tag))filtered.add(n);
    }

    private void getdata() {

        // calling add value event listener method
        // for getting the values from database.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //items.removeAll(items);


                HashMap<String, RecipesItem> hashMap = (HashMap<String, RecipesItem>) snapshot.getValue();

                Log.v("Tags",""+hashMap.keySet());
                Set<String> keySet = hashMap.keySet();
                keySet.forEach((n)->{
                    DataSnapshot newsnapshot = snapshot.child(n);
                    RecipesItem recipesItem = newsnapshot.getValue(RecipesItem.class);
                    items.add(recipesItem);
                    Log.v("Tags",""+recipesItem.getRecipesName());
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // calling on cancelled method when we receive
                // any error or we are not able to get the data.
                //Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onItemClicked(int position) {
        ((MainActivity)getActivity()).openRecipe(items.get(position));
    }
}
