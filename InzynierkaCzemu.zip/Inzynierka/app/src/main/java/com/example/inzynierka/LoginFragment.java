package com.example.inzynierka;

import static android.app.Activity.RESULT_OK;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.identity.BeginSignInRequest;
import com.google.android.gms.auth.api.identity.SignInClient;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import java.io.IOException;


public class LoginFragment extends Fragment {


    Button BSelectImage;

    // One Preview Image
    ImageView IVPreviewImage;

    // constant to compare
    // the activity result code
    int SELECT_PICTURE = 200;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    /*@Override
    public void onStart() {
        super.onStart();
        btSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Initialize sign in intent
                ActivityResultLauncher<Intent> startForResult = registerForActivityResult(new ActivityResultContracts
                        .StartActivityForResult(), result -> {
                    Intent data = result.getData();
                    SignInCredential googleCredential = null;
                    try {
                        googleCredential = oneTapClient.getSignInCredentialFromIntent(data);
                    } catch (ApiException e) {
                        e.printStackTrace();
                    }
                    String idToken = googleCredential.getGoogleIdToken();
                    if (idToken !=  null) {
                        // Got an ID token from Google. Use it to authenticate
                        // with Firebase.
                        AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(idToken, null);
                        firebaseAuth.signInWithCredential(firebaseCredential)
                                .addOnCompleteListener(((MainActivity)getActivity()), new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        if (task.isSuccessful()) {
                                            // Sign in success, update UI with the signed-in user's information
                                            Log.d(TAG, "signInWithCredential:success");
                                            FirebaseUser user = firebaseAuth.getCurrentUser();

                                        } else {
                                            // If sign in fails, display a message to the user.
                                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                                            Toast.makeText(getContext(),"Tekst",Toast.LENGTH_LONG);
                                        }
                                    }
                                });
                    }

                });
                Intent intent = googleSignInClient.getSignInIntent();
                // Start activity for result
                startForResult.launch(intent);
            }

        });
    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_login, container, false);
        BSelectImage = view.findViewById(R.id.SelectImg);
        IVPreviewImage = view.findViewById(R.id.imageView2);

        BSelectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imageChooser();
            }
        });

       /* btSignIn = view.findViewById(R.id.bt_sign_in);

        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("219109991180-9bo91bldn4h6lipkc595uji1l952rfk5.apps.googleusercontent.com")
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(((MainActivity)getActivity()), googleSignInOptions);
*/
//        btSignIn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                // Initialize sign in intent
//                ActivityResultLauncher<Intent> startForResult = registerForActivityResult(new ActivityResultContracts
//                        .StartActivityForResult(), result -> {
//                    Intent data = result.getData();
//                    SignInCredential googleCredential = null;
//                    try {
//                        googleCredential = oneTapClient.getSignInCredentialFromIntent(data);
//                    } catch (ApiException e) {
//                        e.printStackTrace();
//                    }
//                    String idToken = googleCredential.getGoogleIdToken();
//                    if (idToken !=  null) {
//                        // Got an ID token from Google. Use it to authenticate
//                        // with Firebase.
//                        AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(idToken, null);
//                        firebaseAuth.signInWithCredential(firebaseCredential)
//                                .addOnCompleteListener(((MainActivity)getActivity()), new OnCompleteListener<AuthResult>() {
//                                    @Override
//                                    public void onComplete(@NonNull Task<AuthResult> task) {
//                                        if (task.isSuccessful()) {
//                                            // Sign in success, update UI with the signed-in user's information
//                                            Log.d(TAG, "signInWithCredential:success");
//                                            FirebaseUser user = firebaseAuth.getCurrentUser();
//
//                                        } else {
//                                            // If sign in fails, display a message to the user.
//                                            Log.w(TAG, "signInWithCredential:failure", task.getException());
//                                            Toast.makeText(getContext(),"Tekst",Toast.LENGTH_LONG);
//                                        }
//                                    }
//                                });
//                    }
//
//                });
//                Intent intent = googleSignInClient.getSignInIntent();
//                // Start activity for result
//                startForResult.launch(intent);
//            }
//
//        });
        return view;
    }

    private void imageChooser()
    {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);

        launchSomeActivity.launch(i);
    }

    ActivityResultLauncher<Intent> launchSomeActivity
            = registerForActivityResult(
            new ActivityResultContracts
                    .StartActivityForResult(),
            result -> {
                if (result.getResultCode()
                        == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    // do your operation from here....
                    if (data != null
                            && data.getData() != null) {
                        Uri selectedImageUri = data.getData();
                        try {


                            IVPreviewImage.setImageURI(selectedImageUri);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });





}