package com.example.inzynierka.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inzynierka.R;
import com.example.inzynierka.RecipesItem;
import com.example.inzynierka.SelectListener;
import com.example.inzynierka.viewHolders.RecipesViewHolder;

import java.util.ArrayList;

public class RecipesListAdapter extends RecyclerView.Adapter<RecipesViewHolder> {
    ArrayList<RecipesItem> items;
    private SelectListener listener;


    public RecipesListAdapter(ArrayList<RecipesItem> items,SelectListener listener){
        this.items = items;
        this.listener = listener;
    }

    @NonNull
    @Override
    public RecipesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new RecipesViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.recipes_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecipesViewHolder holder, int position) {
        holder.recipeName.setText(items.get(position).getRecipesName());
        holder.recipeDescription.setText(items.get(position).getDescription());
        holder.recipeDescription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClicked(holder.getAdapterPosition());
            }
        });
    }


    @Override
    public int getItemCount() {
        return items.size();
    }
}
