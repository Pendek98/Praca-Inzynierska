package com.example.inzynierka;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.inzynierka.adapters.FragmentAdapter;
import com.google.android.gms.auth.api.identity.BeginSignInRequest;
import com.google.android.gms.auth.api.identity.BeginSignInResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.SignInClient;
import com.google.android.gms.auth.api.identity.SignInCredential;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.checkerframework.checker.units.qual.A;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final int RC_SIGN_IN = 2;
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://praca-inzynierska-2edb2-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference databaseReference = database.getReference();
    FirebaseDatabase database2 = FirebaseDatabase.getInstance("https://praca-inzynierska-2edb2-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference databaseReference2 = database2.getReference().child("ShoppingList");
    public ArrayList<RecipesItem> przepisy = new ArrayList<>();
    ViewPager2 viewPager2;
    TabLayout tabLayout;
    FragmentManager fragmentManager = getSupportFragmentManager();
    FragmentAdapter adapter;
    ArrayList<IngredientItem> ingredientspop = new ArrayList<>();
    IngredientItem ingredien;
    RecipesItem tmpRecipesItem;


    public ArrayList<IngredientItem> items = new ArrayList<>();
    public ArrayList<IngredientItem> homeitems = new ArrayList<>();
    private AlertDialog.Builder dialogBuilder;
    private AlertDialog dialog;


    SignInButton btSignIn;
    GoogleSignInClient googleSignInClient;
    FirebaseAuth firebaseAuth;
    private SignInClient oneTapClient;
    private BeginSignInRequest signInRequest;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getdata();

        firebaseAuth = FirebaseAuth.getInstance();


        viewPager2 = findViewById(R.id.view_pager);
        tabLayout = findViewById(R.id.tab_layout);


        adapter = new FragmentAdapter(fragmentManager, getLifecycle());
        viewPager2.setAdapter(adapter);
        tabLayout.addTab(tabLayout.newTab().setText("Przepisy"));
        tabLayout.addTab(tabLayout.newTab().setText("Lista Zakupów"));
        tabLayout.addTab(tabLayout.newTab().setText("Dom"));
        tabLayout.addTab(tabLayout.newTab().setText("?????"));


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });
        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                tabLayout.selectTab(tabLayout.getTabAt(position));
            }
        });

    }









    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.v("Login","test 2");

        // Check condition
        if (requestCode == 100) {
            // When request code is equal to 100 initialize task
            Task<GoogleSignInAccount> signInAccountTask = GoogleSignIn.getSignedInAccountFromIntent(data);
            // check condition
            if (signInAccountTask.isSuccessful()) {
                // When google sign in successful initialize string
                String s = "Google sign in successful";
                // Display Toast
                // Initialize sign in account
                try {
                    // Initialize sign in account
                    GoogleSignInAccount googleSignInAccount = signInAccountTask.getResult(ApiException.class);
                    // Check condition
                    if (googleSignInAccount != null) {
                        // When sign in account is not equal to null initialize auth credential
                        AuthCredential authCredential = GoogleAuthProvider.getCredential(googleSignInAccount.getIdToken(), null);
                        // Check credential
                        firebaseAuth.signInWithCredential(authCredential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                // Check condition
                                if (task.isSuccessful()) {
                                    // When task is successful redirect to profile activity display Toast
                                    //startActivity(new Intent(MainActivity.this, ProfileActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

                                } else {
                                    // When task is unsuccessful display Toast}
                            }
                        }
                    });
                }
            } catch (ApiException e) {
                    e.printStackTrace();
                }
            }
    }
    }
*/

    public void CreateRecipe(int numb) {
        viewPager2.setCurrentItem(numb);
    }

    public void writeNewRecipe(RecipesItem recipesItem) {
        DatabaseReference recipes = databaseReference.child("Recipes").push();
        recipes.setValue(recipesItem);
        recipes.push();
    }

   /* public void updateNewRecipe(String name, String desc, ArrayList<String> tags) {
        DatabaseReference recipes = databaseReference.child("Recipes");
        RecipesItem recipesItem = new RecipesItem(name, desc, tags, ingredien);

        recipes.setValue(recipesItem);
        recipes.push();
    }*/

    public void openRecipe(RecipesItem recipe){
        tmpRecipesItem = recipe;
        viewPager2.setCurrentItem(5);
    }


    public void writeNewShoppingItem(IngredientItem ingredientItem) {
        DatabaseReference ingredients = databaseReference.child("ShoppingList").push();
        ingredients.setValue(ingredientItem);
        ingredients.push();
    }

    public void writeNewHomeItem(IngredientItem ingredientItem) {
        DatabaseReference ingredients = databaseReference.child("HomeList").push();
        ingredients.setValue(ingredientItem);
        ingredients.push();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.ingredientmenu, menu);
        return true;
    }

    public void createNewContactDialog() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        ImageView imageView = contactPopupView.findViewById(R.id.newListIcon);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                createSecoundDialog();
            }
        });
    }

    public void createSecoundDialog() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup2, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();
        EditText ingredientName, ingredientAmount;
        Button savebtn;
        ingredientName = (EditText) contactPopupView.findViewById(R.id.newIngredientName);
        ingredientAmount = (EditText) contactPopupView.findViewById(R.id.newIngredientAmount);
        savebtn = (Button) contactPopupView.findViewById(R.id.saveIngredient);

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeNewShoppingItem(new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString()));
                ingredientspop.add(new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString()));
                Log.v("OnClick", "" + ingredientName.getText().toString());
                dialog.dismiss();
            }
        });


    }

    public void createNewContactDialog2() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        ImageView imageView = contactPopupView.findViewById(R.id.newListIcon);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                createSecoundDialog2();
            }
        });
    }

    public void createSecoundDialog2() {

        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup2, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();
        EditText ingredientName, ingredientAmount;
        Button savebtn;
        ingredientName = (EditText) contactPopupView.findViewById(R.id.newIngredientName);
        ingredientAmount = (EditText) contactPopupView.findViewById(R.id.newIngredientAmount);
        savebtn = (Button) contactPopupView.findViewById(R.id.saveIngredient);

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ingredien = new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString());
                dialog.dismiss();
            }
        });
    }


    public ArrayList<IngredientItem> getIngredients() {
        return items;
    }



    public void deletedata(IngredientItem ing) {
        databaseReference2.child(ing.ingredientID).removeValue();
    }

    public void deleteHomedata(IngredientItem ing){
        DatabaseReference dataRefnew = database.getReference().child("HomeList");
        dataRefnew.child(ing.ingredientID).removeValue();
    }

    public ArrayList<RecipesItem> getPrzepisy(){
        return przepisy;
    }

    private void getdata() {

        // calling add value event listener method
        DatabaseReference dataRef1 = database.getReference().child("ShoppingList");
        DatabaseReference dataRef2 = database.getReference().child("Recipes");
        DatabaseReference dataRef3 = database.getReference().child("HomeList");
        // for getting the values from database.
        dataRef1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                items.removeAll(items);
                HashMap<String, IngredientItem> hashMap = (HashMap<String, IngredientItem>) snapshot.getValue();

                Log.v("Tags", "" + hashMap.keySet());
                Set<String> keySet = hashMap.keySet();
                keySet.forEach((n) -> {
                    DataSnapshot newsnapshot = snapshot.child(n);
                    IngredientItem recipesItem = newsnapshot.getValue(IngredientItem.class);
                    items.add(0, new IngredientItem(recipesItem.getIngredientName(), recipesItem.getAmount()));
                    items.get(0).setIngredientID(n);
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        dataRef2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                przepisy.removeAll(przepisy);
                HashMap<String, RecipesItem> hashMap = (HashMap<String, RecipesItem>) snapshot.getValue();

                Log.v("Tags",""+hashMap.keySet());
                Set<String> keySet = hashMap.keySet();
                keySet.forEach((n)->{
                    DataSnapshot newsnapshot = snapshot.child(n);
                    RecipesItem recipesItem = newsnapshot.getValue(RecipesItem.class);
                    przepisy.add(recipesItem);
                    Log.v("Tags",""+recipesItem.getRecipesName());
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        dataRef3.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                homeitems.removeAll(homeitems);
                HashMap<String, IngredientItem> hashMap = (HashMap<String, IngredientItem>) snapshot.getValue();

                Log.v("Tags", "" + hashMap.keySet());
                Set<String> keySet = hashMap.keySet();
                keySet.forEach((n) -> {
                    DataSnapshot newsnapshot = snapshot.child(n);
                    IngredientItem recipesItem = newsnapshot.getValue(IngredientItem.class);
                    homeitems.add(0, new IngredientItem(recipesItem.getIngredientName(), recipesItem.getAmount()));
                    homeitems.get(0).setIngredientID(n);
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public ArrayList<IngredientItem> getHomeIngredient() {
        return homeitems;
    }

    public void createNewContactDialogHome() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();

        ImageView imageView = contactPopupView.findViewById(R.id.newListIcon);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                createSecoundDialogHome();
            }
        });
    }

    public void createSecoundDialogHome() {
        dialogBuilder = new AlertDialog.Builder(this);
        final View contactPopupView = getLayoutInflater().inflate(R.layout.popup2, null);
        dialogBuilder.setView(contactPopupView);
        dialog = dialogBuilder.create();
        dialog.show();
        EditText ingredientName, ingredientAmount;
        Button savebtn;
        ingredientName = (EditText) contactPopupView.findViewById(R.id.newIngredientName);
        ingredientAmount = (EditText) contactPopupView.findViewById(R.id.newIngredientAmount);
        savebtn = (Button) contactPopupView.findViewById(R.id.saveIngredient);

        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                writeNewHomeItem(new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString()));
                ingredientspop.add(new IngredientItem(ingredientName.getText().toString(), ingredientAmount.getText().toString()));
                Log.v("OnClick", "" + ingredientName.getText().toString());
                dialog.dismiss();
            }
        });


    }

    /*private void getRecipedata() {

        // calling add value event listener method
        // for getting the values from database.
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                przepisy.removeAll(przepisy);


                HashMap<String, RecipesItem> hashMap = (HashMap<String, RecipesItem>) snapshot.getValue();

                Log.v("Tags",""+hashMap.keySet());
                Set<String> keySet = hashMap.keySet();
                keySet.forEach((n)->{
                    DataSnapshot newsnapshot = snapshot.child(n);
                    RecipesItem recipesItem = newsnapshot.getValue(RecipesItem.class);
                    przepisy.add(recipesItem);
                    Log.v("Tags",""+recipesItem.getRecipesName());
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // calling on cancelled method when we receive
                // any error or we are not able to get the data.
                //Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }*/

}

