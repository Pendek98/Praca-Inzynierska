package com.example.inzynierka;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.inzynierka.adapters.HomeAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;


public class ThirdFragment extends Fragment implements SelectListener{

    public ArrayList<IngredientItem> items = new ArrayList<>();
    FirebaseDatabase database = FirebaseDatabase.getInstance("https://praca-inzynierska-2edb2-default-rtdb.europe-west1.firebasedatabase.app/");
    DatabaseReference databaseReference = database.getReference().child("HomeList");
    View tmp;
    RecyclerView recyclerView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        items.addAll(0,((MainActivity)getActivity()).getHomeIngredient());
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_third, container, false);
        tmp = view;

        recyclerView = view.findViewById(R.id.HomeIngredientsList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setAdapter(new HomeAdapter(items,this));
        return view;
    }


  /*  private void getdata() {

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                items.removeAll(items);


                HashMap<String, IngredientItem> hashMap = (HashMap<String, IngredientItem>) snapshot.getValue();

                Log.v("Tags",""+hashMap.keySet());
                Set<String> keySet = hashMap.keySet();

                keySet.forEach((n)->{
                    DataSnapshot newsnapshot = snapshot.child(n);
                    IngredientItem ingredientItem = newsnapshot.getValue(IngredientItem.class);
                    items.add(ingredientItem);
                    Log.v("Tags",""+ingredientItem.getIngredientName());
                });



            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // calling on cancelled method when we receive
                // any error or we are not able to get the data.
                //Toast.makeText(MainActivity.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }*/
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        view.findViewById(R.id.AddHomeIngredient).setOnClickListener(v -> {
            ((MainActivity)getActivity()).createNewContactDialogHome();
            items.removeAll(items);
            items.addAll(0,((MainActivity)getActivity()).getHomeIngredient());

            recyclerView.setAdapter(new HomeAdapter(items,this));

        });



    }
    @Override
    public void onItemClicked(int position) {
        ((MainActivity)getActivity()).deleteHomedata(items.get(position));
        items.remove(position);
        recyclerView.getAdapter().notifyDataSetChanged();
    }

    /*
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RecyclerView recyclerView = view.findViewById(R.id.HomeIngredientsList);;
        view.findViewById(R.id.DeleteIngredient).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = recyclerView.findViewHolderForAdapterPosition();
                items.remove(items.indexOf(this));
            }
        });

    }*/

}