package com.example.inzynierka;

public interface SelectListener {
    void onItemClicked(int position);
}
